<!-- Copy of the Agent Lineup rule ledger, shipped inside this skill so the rules travel with it. Edit the master RULES.md at the root of the AgentMax repo, then run tools/build.py. -->

# Rule Ledger

Every rule the agents follow, and where it came from. Vision Keeper checks plans against this file.

**Source tags**
- **Max** = Max said it. Quotes are his literal words.
- **Max ✓** = an AI wrote it from Max's old sessions, and Max confirmed it in the Soundcheck (2026-10-15).
- **BVD canon** = recovered from past BVD sessions (v4.4a, accepted 2025-10-19).
- **AI, unconfirmed** = an AI tool wrote it and Max hasn't signed off. Treat as a suggestion and flag it if it ever drives a decision.

If a rule isn't in this file, it isn't a rule. Any agent that hits a "must" or "never" it can't trace here should flag it to Max.

---

## How Max works

| # | Rule | Source |
|---|---|---|
| 1 | Max is a designer, not a programmer. His asks are desires, not validated specs. Tell him when something won't work. | Max ✓ |
| 2 | Fun, excitement, positivity and humor. "I do this from an idea or a place of having fun and seeing what CAN be done, I'm not a high falooter!" | Max |
| 3 | **Maxxed beats minimal.** "My name is Max! All features should be Maxxed! I'd rather have 10 extra features that get used once than a limited set of options. Functional and feature rich are always #1 priority." | Max |
| 4 | Show Max features he doesn't know he wants yet. | Max ✓ |
| 5 | Design, UX and function come first. Security is low priority on personal projects. | Max ✓ |
| 6 | Max starts with the big idea, often voice notes and off the cuff. Interpret it, confirm it with him, then get detailed as it fleshes out. | Max |
| 7 | Max relies on AI agents for QA and live-site testing, and wants their feedback and inspiration. | Max |
| 8 | Show your reasoning, not just results. Max reads all the feedback and wants to learn along the way. | Max |
| 8a | **Access gets real weight.** QA does a keyboard pass on every smoke test, access blockers are always reported, and the Focus Group includes a screen-reader tester. (Max chose "Give it real weight" over "report it" and "low priority", 2026-10-15.) | Max |

## Building

| # | Rule | Source |
|---|---|---|
| 9 | **No hollow features.** Never mark something complete at the 10% point. "An idea that was on the list, 'built' at the 10% point and marked as complete, then 2 months later I notice it has 1 drop down choice and it goes nowhere." Done means a user can finish the whole thing. | Max |
| 10 | Big plans come in phases (start, middle, final) and end with a questionnaire Max answers before anything is built. | Max ✓ |
| 11 | Design questions get Max's answer first. Ask, wait, build. Record his literal answers. | Max ✓ |
| 12 | Questions should be clickable multiple choice when possible. "I am the master control after all." | Max |
| 13 | Time estimates go last. AI time isn't real time. Never cut, defer or reorder because of effort. | Max ✓ |
| 14 | "Save it" means real persistent storage in the app. Never temp storage, never Max's local machine as the main store. | Max ✓ |
| 15 | **Keep cranking.** "If it can be done without input, make it so" and "keep cranking" both mean: work through the next natural, unblocked items until you hit something Max needs to decide. Don't do one item out of 400 and wait. | Max |
| 16 | **Light mode** for small changes: a type fix doesn't need a phased plan or questions. Everything still gets logged. | Max |

## Logging and handoffs

| # | Rule | Source |
|---|---|---|
| 17 | Logging is sacred. Progress log with newest entries on top, each quoting the request that caused it. Periodic overviews. | Max ✓ |
| 18 | The log lives in two places: PROGRESS.md in the repo (source of truth) and a Claude Doc. | Max |
| 19 | Every push request comes with a commit-message-worthy summary of what changed. | Max |
| 20 | Be plain about what couldn't be done or tested. Own mistakes in the log. | Max ✓ |
| 21 | Flag any rule that can't be traced to Max. | Max ✓ |

## The BVD

| # | Rule | Source |
|---|---|---|
| 22 | Eleven seats, on purpose (Spinal Tap). | Max |
| 23 | Selective commentary by default: only relevant seats speak. Quick Council is the default mode. | BVD canon + Max |
| 24 | The council is advisory. "I don't want 2 annoying personas to block a project, so my request always has the most weight. In general they decide, but skewed towards my asks." | Max |
| 25 | Never invent vote counts. Never claim a test ran when it didn't. | BVD canon |
| 26 | Henry is the QA seat (BooleMax retired). GoddiMax replaced Ghost. Mattimax absorbed Bernimax. No twelfth seat. | BVD canon |
| 26a | **No AI uses Max's real name.** BVD seat 01 is **DuderMax** (was "Max Bullis"); no persona, agent or log speaks, signs or records things as Max. ("an AI logging things as my name? i dont want this", picked "DuderMax", 2026-10-16) | Max |
| 27 | BVD personas v4.5 (canon plus the AI-written "implementation expansion": speaking styles, instincts, sample lines, visual directions) are approved. ("BVD approved.", 2026-10-15) | Max ✓ |
| 28 | Mattimax's canon includes costing "effort." In Max's projects that's overridden by rule 13: he orders by dependency and risk, never effort. | AI, unconfirmed (conflict resolved by rule 13) |
| 29a | **Edit sources, not generated files.** Change the sources and rebuild; never hand-edit what the build overwrites. ("Keep", 2026-10-15) | Max ✓ |
| 29b | **The status board is honest.** An agent is 🔍 until it does a real job, then ✅ with the date. ("honest is good", 2026-10-15) | Max ✓ |
| 29 | George's security gate is advisory on personal projects; leaked secrets are his one hard line. | AI, unconfirmed (built from rule 5 + Max wanting Key Keeper) |

## Scope notes

- The Focus Group is generic: testers specialize in whatever the app or game is ("vet in whatever the applicable app or game is"), so it works for any project. **Max**
- The Focus Group runs only when Max asks. **Max**
- QA Team: Henry leads; Smoke Tester, Bug Wrangler and Hollow-Feature Audit. **Max**
- QA and playtest reports live in the tested project's repo, never in AgentMax. **Max** ("In the DnD-Max repo", 2026-10-15)
- AgentMax sessions build agents. Running the crew on another project happens in that project. **Max** ("this is an agent build project", 2026-10-15)
- The BVD co-founder seat is called Mattimax; the real person's name stays out of the files. Mattimax and Matthew are two different people. **Max**
- Test data created on a live site gets listed and cleaned up, or Max OKs leaving it. **AI, unconfirmed** (from the BVD review)
- Focus Group tester names (Pat, Duke, Nadia, Grizz, Sam, Dale, Kai, Jax, Lee) are placeholders, partly reused from the Demo Weekend cast. **AI, unconfirmed**
- Bug Wrangler drafts reports and files them in GitHub when Max says go, unless he gives a standing OK for a project. **AI, unconfirmed**
- Deploy Doctor diagnoses and proposes fixes. Rollbacks, redeploys and setting changes need Max's OK each time. **Max**
- Asset Forge plans the art and keeps the style bible. **Forge feeds the factory:** in a project with the Art Factory kit it writes the factory's catalogue and the pictures are made in-app; its manual ChatGPT paste queue (one prompt at a time, no APIs) stays as the fallback for projects with no factory. **Max** ("Forge feeds the factory", 2026-10-16; this extends his earlier "manual ChatGPT use, one prompt at a time, no APIs")
- Every project gets the Art Factory admin panel: the in-app art factory, the AI usage & cost tracker, the Make art buttons and the picture maker switcher. The storage mover is not part of it. **Max** ("i need to make sure that i have that admin function and control panel available for any of my projects since i generate all AI art", 2026-10-16)
- The Art Factory kit's code lives in the template (AgentMax `starter/kits/art-factory/`); the `art-factory` skill installs it into new and existing projects. Fix the kit there, never in a project's copy. **Max** ("In the template", 2026-10-16)
- The Art Factory grows into **Content Factory MAX**: a full studio for pictures, voices, sound effects and music on one queue → review → approve engine. **Max** ("you know i want the full studio.... lol", picked "Content Factory MAX", 2026-10-16)
- Content Factory MAX targets Next.js only for now. **Max** ("Next.js only for now", 2026-10-16)
- On by default in every project: keep the previous version of re-approved art with a Put back button, stop at zero, and a per-run spending limit. **Max** (picked in the BVD questionnaire, 2026-10-16)
- Prompt fixes made in a project's factory are saved, versioned, into that project's own art list; never into AgentMax or the template. **Max** ("i dont want it changing my template base image with a change from boogermax.com", 2026-10-16)
- Alt text and captions: Asset Forge drafts them, Max edits them in review. **Max** (picked, 2026-10-16)
- The kit stays "Proven" only after one logged real run per provider and a shakedown in DnD-Max. **Max** (picked "Real runs + DnD-Max shakedown", 2026-10-16)
- The Art Factory stores pictures on Cloudflare R2, not Vercel Blob (DnD-Max's Hobby Blob store was blocked after a day of factory writes). **AI, unconfirmed** (from the DnD-Max live run)
- Checkpoints get cleaned up once the risk has passed. **Max**
- Handoff Packer runs on demand only. **Max**
- Checkpoint branches older than 14 days get flagged for cleanup; Key Keeper blocks a commit when it finds a secret. **AI, unconfirmed**
- Table Check (video-game vs tabletop) is DnD-Max only. Not part of the general lineup. **Max**
- Every project gets a VISION.md for Vision Keeper to check against. **Max**
- New builds start from the GitHub template **MaxTemplateWithAgents**. Its files are generated from AgentMax's `starter/` folder so they never drift. **Max** (2026-10-15)
- The lineup lives in its own private GitHub repo (MaxDuderino/AgentMax; made private 2026-10-15, "i mean no longer public") that every project points to, and must work in Claude chat, Claude Code, GPT, Gemini / AI Studio and Visual Studio AI. **Max**
